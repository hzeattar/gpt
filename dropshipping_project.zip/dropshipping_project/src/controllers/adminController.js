exports.dashboard = (req, res) => {
  // TODO: implement admin dashboard logic
  res.json({ message: 'Admin dashboard endpoint placeholder' });
};
