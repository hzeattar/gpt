exports.addProduct = (req, res) => {
  // TODO: supplier adds new product with price and stock
  res.json({ message: 'Add product placeholder' });
};

exports.listOrders = (req, res) => {
  // TODO: list orders associated with this supplier
  res.json({ message: 'List orders placeholder' });
};
