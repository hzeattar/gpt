exports.listProducts = (req, res) => {
  // TODO: return list of products available to marketers
  res.json({ message: 'List products placeholder' });
};

exports.createOrder = (req, res) => {
  // TODO: create new order for marketer
  res.json({ message: 'Create order placeholder' });
};
