const express = require('express');
const router = express.Router();
const supplierController = require('../controllers/supplierController');

// Supplier adds new product
router.post('/products', supplierController.addProduct);
// Supplier list orders
router.get('/orders', supplierController.listOrders);

module.exports = router;
