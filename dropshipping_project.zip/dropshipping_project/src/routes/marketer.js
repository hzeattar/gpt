const express = require('express');
const router = express.Router();
const marketerController = require('../controllers/marketerController');

// List all products for marketer
router.get('/products', marketerController.listProducts);
// Create new order
router.post('/orders', marketerController.createOrder);

module.exports = router;
