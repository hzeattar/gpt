-- Dropshipping modifications for Active eCommerce
--
-- This SQL script mirrors the changes introduced by the migration files in
-- this directory.  It is intended for environments where running Laravel
-- migrations is not possible.  Use with caution and adjust table names
-- according to your own database prefix or customisations.

-- 1. Add a base_price column to the products table
ALTER TABLE `products`
    ADD COLUMN `base_price` DECIMAL(12,2) NULL AFTER `unit_price`;

-- 2. Create an orders table for marketer orders
CREATE TABLE `orders` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `marketer_id` BIGINT UNSIGNED NOT NULL,
    `product_id` BIGINT UNSIGNED NOT NULL,
    `customer_name` VARCHAR(255) NOT NULL,
    `customer_phone` VARCHAR(50) NOT NULL,
    `customer_address` VARCHAR(500) NOT NULL,
    `customer_city` VARCHAR(255) DEFAULT NULL,
    `base_price` DECIMAL(12,2) NOT NULL,
    `final_price` DECIMAL(12,2) NOT NULL,
    `profit_margin` DECIMAL(12,2) NOT NULL,
    `status` ENUM('pending','shipped','delivered','returned') NOT NULL DEFAULT 'pending',
    `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `orders_marketer_id_foreign` FOREIGN KEY (`marketer_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    CONSTRAINT `orders_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Insert marketer role into roles table (adjust according to your schema)
INSERT INTO `roles` (`name`, `label`, `guard_name`, `created_at`, `updated_at`)
    VALUES ('marketer', 'Marketer', 'web', NOW(), NOW())
    ON DUPLICATE KEY UPDATE `updated_at` = NOW();