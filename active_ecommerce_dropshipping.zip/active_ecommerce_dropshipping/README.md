# Active eCommerce Dropshipping Modifications

This folder contains a set of example modifications and new files designed to
convert the **Active eCommerce CMS** (a Laravel‑based multi‑vendor marketplace)
into a **dropshipping platform for marketers** similar in spirit to
[Taager.com](https://www.taager.com/).  These changes introduce a new
`Marketer` role, add a `base_price` column to products, and implement an
order workflow where marketers manually create orders on behalf of their
customers, set their own selling price and earn a commission on successful
deliveries.  The platform administrator remains the sole supplier and is
responsible for inventory, fulfilment and payouts.

> **Important:**
>
> These files are **not** a complete Laravel application.  They are intended
> as illustrative examples of the structural changes required to transform
> Active eCommerce into a dropshipping platform.  To apply these changes to
> your existing installation you will need to integrate the migrations,
> models, controllers, middleware and views into your current codebase and
> adapt them to match the versions and naming conventions you are using.

## Overview of Changes

1. **User Roles**
   * A new `Marketer` role is added.  Marketers cannot add or modify
     products; they can only browse the catalogue published by the admin.
   * Admins are the sole suppliers; they add products with a `base_price` and
     manage stock, fulfilment and payouts.

2. **Database Migrations**
   * `add_base_price_to_products_table.php` – adds a nullable `base_price`
     column to the existing `products` table.
   * `create_orders_table.php` – defines an `orders` table to store
     marketer‑created orders, including customer details, final selling
     price, base price, profit margin and status.

3. **Models**
   * `Marketer.php` – a simple model representing a marketer (extends
     the existing `User` model and provides a helper method to determine if
     the authenticated user is a marketer).
   * `Order.php` – encapsulates order data and defines relationships
     to `User` (as marketer) and `Product`.

4. **Controllers**
   * `Marketer/OrderController.php` – enables marketers to create orders,
     calculate their profit margin, and view the status of their orders.
   * `Admin/OrderController.php` – allows admins to manage orders,
     update statuses based on shipping events and trigger payout logic.

5. **Middleware**
   * `MarketerMiddleware.php` – restricts certain routes to users with
     the marketer role.

6. **Routes**
   * Example route definitions show how to register marketer‑specific order
     routes and secure them with middleware.

7. **Views**
   * Blade templates illustrate simple forms for creating orders and
     listing orders in the marketer dashboard.

8. **Seeders**
   * An example seeder demonstrates how to insert the marketer role into the
     roles table.

9. **SQL Script**
   * `dropshipping_modifications.sql` – for environments where migrations
     cannot be run automatically, this SQL script adds the `base_price` column
     and creates the `orders` table.

## How to Use These Files

1. Copy the contents of this directory into your existing Active eCommerce
   application, preserving the folder structure (e.g. copy the migration
   files into `database/migrations`, the models into `app/Models`, etc.).
2. Run the migrations using `php artisan migrate` to create/alter the
   necessary database tables.
3. Register the new `MarketerMiddleware` in your `Http\Kernel.php` and add
   appropriate route entries as shown in `routes/marketer.php`.
4. Update your authentication logic to assign the `marketer` role to
   eligible users.  You may modify your existing `User` model or use a
   permissions package such as spatie/laravel-permission.
5. Integrate the provided controllers and views into your dashboard.
6. Test the complete workflow: Admin adds products with a base price,
   marketers create orders on behalf of customers, admin fulfils the
   orders and pays out marketer commissions when deliveries are confirmed.

These examples should serve as a starting point.  Depending on the
customisations and extensions you already have in your Active eCommerce
installation, you may need to adjust namespaces, table names or relationships
accordingly.