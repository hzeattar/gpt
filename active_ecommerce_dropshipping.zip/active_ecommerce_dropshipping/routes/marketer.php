<?php

use App\Http\Controllers\Marketer\OrderController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Marketer Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for marketers. These routes
| should be loaded by your RouteServiceProvider and assigned to the
| `marketer` middleware group defined in your Kernel.
|
*/

Route::middleware(['auth', 'marketer'])->prefix('marketer')->name('marketer.')->group(function () {
    Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/create', [OrderController::class, 'create'])->name('orders.create');
    Route::post('/orders', [OrderController::class, 'store'])->name('orders.store');
});