<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * The Order model represents a dropshipping order created by a marketer.
 */
class Order extends Model
{
    protected $fillable = [
        'marketer_id',
        'product_id',
        'customer_name',
        'customer_phone',
        'customer_address',
        'customer_city',
        'base_price',
        'final_price',
        'profit_margin',
        'status',
    ];

    /**
     * The marketer who created the order.
     */
    public function marketer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'marketer_id');
    }

    /**
     * The product associated with the order.
     */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}