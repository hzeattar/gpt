<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * Simple wrapper model to represent a marketer.
 *
 * In an Active eCommerce installation the User model already exists and
 * determines the user's role.  This class can be used to encapsulate
 * marketer‑specific behaviour or query scopes.  It assumes that the
 * underlying users table contains a `user_type` or similar column which
 * distinguishes marketers from other roles.
 */
class Marketer extends User
{
    /**
     * Determine if the given user instance is a marketer.
     */
    public function isMarketer(): bool
    {
        return $this->user_type === 'marketer';
    }

    /**
     * Orders created by this marketer.
     */
    public function orders(): HasMany
    {
        return $this->hasMany(Order::class, 'marketer_id');
    }
}