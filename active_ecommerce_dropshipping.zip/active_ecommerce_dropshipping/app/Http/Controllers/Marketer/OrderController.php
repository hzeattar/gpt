<?php

namespace App\Http\Controllers\Marketer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

/**
 * Controller allowing marketers to create and manage orders.
 */
class OrderController extends Controller
{
    /**
     * Display a listing of the marketer's orders.
     */
    public function index(): View
    {
        $marketer = Auth::user();
        $orders = Order::where('marketer_id', $marketer->id)->latest()->paginate(15);
        return view('marketer.order.index', compact('orders'));
    }

    /**
     * Show the form for creating a new order.
     */
    public function create(): View
    {
        // Fetch all products with base_price defined.  You may want to add
        // additional conditions (e.g. only in stock, only published).
        $products = Product::whereNotNull('base_price')->where('published', 1)->get();
        return view('marketer.order.create', compact('products'));
    }

    /**
     * Store a newly created order in the database.
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'product_id'      => 'required|exists:products,id',
            'final_price'     => 'required|numeric|min:0',
            'customer_name'   => 'required|string|max:255',
            'customer_phone'  => 'required|string|max:50',
            'customer_address'=> 'required|string|max:500',
            'customer_city'   => 'nullable|string|max:255',
        ]);

        $product = Product::findOrFail($request->input('product_id'));
        $basePrice = $product->base_price ?? $product->unit_price;
        $finalPrice = $request->input('final_price');
        $profit = $finalPrice - $basePrice;

        $order = Order::create([
            'marketer_id'     => Auth::id(),
            'product_id'      => $product->id,
            'customer_name'   => $request->input('customer_name'),
            'customer_phone'  => $request->input('customer_phone'),
            'customer_address'=> $request->input('customer_address'),
            'customer_city'   => $request->input('customer_city'),
            'base_price'      => $basePrice,
            'final_price'     => $finalPrice,
            'profit_margin'   => $profit,
            'status'          => 'pending',
        ]);

        return redirect()->route('marketer.orders.index')
            ->with('success', 'Order created successfully');
    }
}