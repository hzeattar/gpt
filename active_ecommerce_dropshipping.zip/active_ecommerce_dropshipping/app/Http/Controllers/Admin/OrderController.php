<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * Controller for admins to manage dropshipping orders.
 */
class OrderController extends Controller
{
    /**
     * Display a listing of all orders.
     */
    public function index(): View
    {
        $orders = Order::with(['marketer', 'product'])->latest()->paginate(25);
        return view('admin.order.index', compact('orders'));
    }

    /**
     * Show the specified order with details.
     */
    public function show(int $id): View
    {
        $order = Order::with(['marketer', 'product'])->findOrFail($id);
        return view('admin.order.show', compact('order'));
    }

    /**
     * Update the status of an order.
     */
    public function updateStatus(Request $request, int $id): RedirectResponse
    {
        $request->validate([
            'status' => 'required|in:pending,shipped,delivered,returned',
        ]);
        $order = Order::findOrFail($id);
        $order->status = $request->input('status');
        $order->save();

        // When an order is delivered, you might trigger payout logic here.
        // e.g. move profit_margin to marketer's withdrawable balance.

        return redirect()->back()->with('success', 'Order status updated');
    }
}