<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

/**
 * Seeder that inserts a marketer role into the roles table.
 *
 * Adjust the table and column names according to your existing schema.
 */
class MarketerRoleSeeder extends Seeder
{
    public function run(): void
    {
        // Example using a simple roles table.  If you're using a
        // permissions package like spatie/laravel-permission you would
        // create a Role model instead.
        DB::table('roles')->updateOrInsert(
            ['name' => 'marketer'],
            [
                'name'       => 'marketer',
                'label'      => 'Marketer',
                'guard_name' => 'web',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        );
    }
}