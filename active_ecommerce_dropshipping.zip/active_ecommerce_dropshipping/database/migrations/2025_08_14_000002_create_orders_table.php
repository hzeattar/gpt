<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Migration to create the orders table used by marketers.
 *
 * Each order stores the marketer who created it, the product selected, the
 * customer details and pricing information.  Profit margin is calculated as
 * final_price minus base_price.  The status tracks the fulfilment
 * lifecycle (pending, shipped, delivered, returned).
 */
class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table): void {
            $table->id();
            // foreign keys to marketer (users table) and product
            $table->unsignedBigInteger('marketer_id');
            $table->unsignedBigInteger('product_id');

            // Customer information (captured by marketer)
            $table->string('customer_name');
            $table->string('customer_phone');
            $table->string('customer_address');
            $table->string('customer_city')->nullable();

            // Pricing
            $table->decimal('base_price', 12, 2);
            $table->decimal('final_price', 12, 2);
            $table->decimal('profit_margin', 12, 2);

            // Order status enumeration
            $table->enum('status', ['pending', 'shipped', 'delivered', 'returned'])->default('pending');

            // Timestamps
            $table->timestamps();

            // Foreign key constraints
            $table->foreign('marketer_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('product_id')->references('id')->on('products')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
}