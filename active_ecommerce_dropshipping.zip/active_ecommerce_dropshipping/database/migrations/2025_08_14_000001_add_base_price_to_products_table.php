<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Migration to add a base_price column to the products table.
 *
 * The `base_price` represents the wholesale cost set by the admin.  It is
 * separate from the selling price chosen by the marketer.  A nullable
 * floating‑point column is added so existing records are unaffected until
 * explicitly updated.
 */
class AddBasePriceToProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table): void {
            // base_price stores the admin‑defined wholesale cost
            $table->decimal('base_price', 12, 2)->nullable()->after('unit_price');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down(): void
    {
        Schema::table('products', function (Blueprint $table): void {
            $table->dropColumn('base_price');
        });
    }
}