@extends('layouts.app')

@section('content')
<div class="container">
    <h1>My Orders</h1>
    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Product</th>
                <th>Customer</th>
                <th>Final Price</th>
                <th>Profit</th>
                <th>Status</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($orders as $order)
                <tr>
                    <td>{{ $order->id }}</td>
                    <td>{{ $order->product->name ?? '' }}</td>
                    <td>{{ $order->customer_name }}</td>
                    <td>{{ number_format($order->final_price, 2) }}</td>
                    <td>{{ number_format($order->profit_margin, 2) }}</td>
                    <td>{{ ucfirst($order->status) }}</td>
                    <td>{{ $order->created_at->format('Y-m-d H:i') }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="7" class="text-center">No orders found.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
    {{ $orders->links() }}
</div>
@endsection