@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Create New Order</h1>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('marketer.orders.store') }}">
        @csrf
        <div class="mb-3">
            <label for="product_id" class="form-label">Product</label>
            <select id="product_id" name="product_id" class="form-select" required>
                <option value="" disabled selected>Select a product</option>
                @foreach ($products as $product)
                    <option value="{{ $product->id }}">
                        {{ $product->name }} (Base: {{ number_format($product->base_price, 2) }})
                    </option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="final_price" class="form-label">Final Selling Price</label>
            <input type="number" step="0.01" class="form-control" id="final_price" name="final_price" required>
        </div>

        <h3>Customer Details</h3>
        <div class="mb-3">
            <label for="customer_name" class="form-label">Name</label>
            <input type="text" class="form-control" id="customer_name" name="customer_name" required>
        </div>
        <div class="mb-3">
            <label for="customer_phone" class="form-label">Phone</label>
            <input type="text" class="form-control" id="customer_phone" name="customer_phone" required>
        </div>
        <div class="mb-3">
            <label for="customer_address" class="form-label">Address</label>
            <input type="text" class="form-control" id="customer_address" name="customer_address" required>
        </div>
        <div class="mb-3">
            <label for="customer_city" class="form-label">City</label>
            <input type="text" class="form-control" id="customer_city" name="customer_city">
        </div>
        <button type="submit" class="btn btn-primary">Create Order</button>
    </form>
</div>
@endsection