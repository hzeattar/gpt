@extends('layouts.app')

@section('content')
<div class="container">
    <h1>All Dropshipping Orders</h1>
    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Marketer</th>
                <th>Product</th>
                <th>Customer</th>
                <th>Base Price</th>
                <th>Final Price</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($orders as $order)
                <tr>
                    <td>{{ $order->id }}</td>
                    <td>{{ $order->marketer->name ?? '' }}</td>
                    <td>{{ $order->product->name ?? '' }}</td>
                    <td>{{ $order->customer_name }}</td>
                    <td>{{ number_format($order->base_price, 2) }}</td>
                    <td>{{ number_format($order->final_price, 2) }}</td>
                    <td>{{ ucfirst($order->status) }}</td>
                    <td>
                        <a href="{{ route('admin.orders.show', $order->id) }}" class="btn btn-sm btn-primary">View</a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{ $orders->links() }}
</div>
@endsection