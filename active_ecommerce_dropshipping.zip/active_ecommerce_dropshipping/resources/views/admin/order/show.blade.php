@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Order #{{ $order->id }}</h1>
    <div class="mb-3">
        <strong>Marketer:</strong> {{ $order->marketer->name ?? '' }}<br>
        <strong>Product:</strong> {{ $order->product->name ?? '' }}<br>
        <strong>Customer:</strong> {{ $order->customer_name }} ({{ $order->customer_phone }})<br>
        <strong>Address:</strong> {{ $order->customer_address }}, {{ $order->customer_city }}<br>
        <strong>Base Price:</strong> {{ number_format($order->base_price, 2) }}<br>
        <strong>Final Price:</strong> {{ number_format($order->final_price, 2) }}<br>
        <strong>Profit Margin:</strong> {{ number_format($order->profit_margin, 2) }}<br>
        <strong>Status:</strong> {{ ucfirst($order->status) }}
    </div>
    <form method="POST" action="{{ route('admin.orders.updateStatus', $order->id) }}">
        @csrf
        <div class="mb-3">
            <label for="status" class="form-label">Update Status</label>
            <select id="status" name="status" class="form-select" required>
                <option value="pending" {{ $order->status === 'pending' ? 'selected' : '' }}>Pending</option>
                <option value="shipped" {{ $order->status === 'shipped' ? 'selected' : '' }}>Shipped</option>
                <option value="delivered" {{ $order->status === 'delivered' ? 'selected' : '' }}>Delivered</option>
                <option value="returned" {{ $order->status === 'returned' ? 'selected' : '' }}>Returned</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
@endsection